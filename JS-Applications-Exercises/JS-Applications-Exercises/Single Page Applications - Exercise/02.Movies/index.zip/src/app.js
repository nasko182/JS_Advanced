import { redirect } from "./redirect.js";



redirect();


